package chapter03;

public class Java01_FlowControl {
    public static void main(String[] args) {

        // TODO 流程控制
        // 所谓的流程控制，其实就是计算机在执行代码时，对指令代码执行顺序的控制
        // Java种的流程控制主要分为3种：
        // 1. 顺序执行 ：代码出现的先后顺序以及语法的先后顺序
        // 变量在使用之前，必须声明并进行了初始化
        int i = 10;
        int j = 10;
        System.out.println( i + j );

    }
}
