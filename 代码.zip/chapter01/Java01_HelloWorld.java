package chapter01;

public class Java01_HelloWorld {
    public static void main(String[] args) {
        // 单行注释：注释得内容
        /*
          TODO 多行注释： 注释得内容
          多行注释： 注释得内容
          多行注释： 注释得内容
          多行注释： 注释得内容
          多行注释： 注释得内容
          多行注释： 注释得内容
         */
        System.out.println("Hello World");
        System.out.println("Hello World");
        System.out.println("Hello World");
        // 双引号 ： 引用
        // TODO Java种双引号得内容称之为字符串
    }
}
