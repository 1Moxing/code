package chapter01;

public class Java02_HelloJava {
    public static void main(String[] args) {
        System.out.println("Hello");
        System.out.println("Hello Java");
        System.out.println("Hello Java");
        System.out.println("Hello Java");
        System.out.println("Hello Java");
        // ctrl + D : 复制当前行
        // ctrl + R : 替换文本内容
    }
}
