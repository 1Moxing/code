package chapter02;

public class Java01_Variable {
    public static void main(String[] args) {

        // TODO 变量
        // 所谓得变量，其实就是可以改变得向量存储
        // TODO 1. 声明变量
        // 数据类型 变量名称
        String name;
        // TODO 2. 变量赋值
        name = "lisi";
        // TODO 3. 变量使用
        System.out.println(name);
        System.out.println(name);
        System.out.println(name);
        System.out.println(name);
        System.out.println(name);

        // 实际开发时，可以将第一步和第二步合并在一起
        String username = "wangwu";
        System.out.println(username);
    }
}
