package chapter02;

public class Java03_Datatype {
    public static void main(String[] args) {

        // TODO 数据类型

        String name = "zhangsan";

        // TODO 数据得存储单位
        // 1. 比特(bit位) : 数据运算得最小存储单位
        // 2. 字节(byte) : 数据最小存储单位

        // bit和byte可以互相转换得
        // 1 byte = 8 bit位

        // KB, MB, GB, TB....PB, EB...
        // 1024 Byte => 1KB
        // 1024 KB => 1MB
        // 1024 MB => 1GB
        // 1024 GB => 1TB

    }
}
