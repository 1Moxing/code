package chapter02;

public class Java03_Datatype_1 {
    public static void main(String[] args) {

        // TODO 基本数据类型

        // TODO 1. 整数类型
        // byte : 8位
        byte b = 10;
        // short ： 16位
        short s = 10;
        // int ： 32位
        int i = 10;
        // long ： 64位
        long lon = 10;

        // TODO 2. 浮点类型：含有小数点得数据类型
        // 根据计算精度分为
        // 默认情况下，小数点得数据会被识别位精度较高得双精度double类型
        // float : 单精度浮点类型,数据需要使用F(f)结尾
        float f = 1.0F;
        // double : 双精度浮点类型
        double d = 2.0;

        // TODO 3. 字符类型
        // 所谓得字符类型，其实就是使用符号标识文字内容
        char c = '@';

        // TODO 4. 布尔类型
        // true, false,标识判断条件是否成立，如果成立，取值位true，如果不成立，那么取值位false
        boolean bln = true;


    }
}
