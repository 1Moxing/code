package chapter08;

public class Java01_IO {
    public static void main(String[] args) throws Exception{

        // TODO Java 数据 + 流（转）操作
        // 数据从哪里来，到哪里去
        // TODO IO
        // I : Input, 输入（In）
        // O : Output 输出（Out）
        // Stream : 流转
    }
}
