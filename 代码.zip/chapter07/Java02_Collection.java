package chapter07;

public class Java02_Collection {
    public static void main(String[] args) {

        // TODO 集合
        // 1. Collection接口
        //    常用的子接口
        //    List ：按照插入顺序保存数据，数据可以重复的
        //         具体的实现类： ArrayList, LinkedList
        //    Set : 集，无序保存，数据不能重复
        //         具体的实现类 HashSet
        //    Queue ： 队列
        //         具体的实现类：ArrayBlockingQueue
        // 2. Map接口
        //    具体的实现 ： HashMap, Hashtable
    }
}
